# We use variable to store data in computers memory. Here are few examples;

'''When varialbe(employee_count) is diclared and run the program then Python interpreter allocates some memory 
in computer and store the varilable value(800) in memory space'''

'''Then the varilable name(emplyee_count) gets a refference for the value(800) in the memory location
so that variable is just like a label for the memory location'''

employee_count = 800

'''Now the varialbe can be used anywhere in the program to get access to the memory location'''

print(employee_count)

# Another example
my_name = 'Khalid'
my_age = 37

print(my_name + " " +str(my_age))

# Variable name should descriptive and meaningful
# In this course the veriable name is writter in lowercase snake_case
